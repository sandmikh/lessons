def get_message():
    return "Misha molodec"


def print_message():
    print get_message()